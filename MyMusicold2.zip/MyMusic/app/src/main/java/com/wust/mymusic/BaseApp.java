package com.wust.mymusic;

public class BaseApp {
}
